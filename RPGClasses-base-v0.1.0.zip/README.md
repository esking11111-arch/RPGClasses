# RPGClasses

TShock RPG/Class system.

Target:
- Terraria 1.4.5.6
- TShock 6.1.0
- .NET 9

## Base version

Version 0.1.0 only verifies that the plugin can be built and loaded by TShock.

Commands:
- `/rpg`
- `/rpg version`

The full RPG system will be added in later versions.
