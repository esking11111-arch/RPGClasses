using System;
using Terraria;
using TerrariaApi.Server;
using TShockAPI;

namespace RPGClasses;

[ApiVersion(2, 1)]
public sealed class RPGClasses : TerrariaPlugin
{
    public override string Name => "RPGClasses";
    public override Version Version => new(0, 1, 0);
    public override string Author => "esking11111";
    public override string Description => "RPG class system for TShock.";

    public RPGClasses(Main game) : base(game)
    {
    }

    public override void Initialize()
    {
        Commands.ChatCommands.Add(
            new Command("rpgclasses.use", HandleRpgCommand, "rpg", "rpgclasses")
            {
                HelpText = "RPGClasses commands."
            }
        );

        TShock.Log.ConsoleInfo("[RPGClasses] Loaded successfully. Base version 0.1.0");
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            var command = Commands.ChatCommands.Find(c =>
                c.Names.Contains("rpg", StringComparer.OrdinalIgnoreCase));

            if (command != null)
                Commands.ChatCommands.Remove(command);
        }

        base.Dispose(disposing);
    }

    private static void HandleRpgCommand(CommandArgs args)
    {
        if (args.Parameters.Count == 0)
        {
            args.Player.SendInfoMessage(
                "[RPGClasses] Plugin is working! Version 0.1.0"
            );
            args.Player.SendInfoMessage(
                "Use /rpg version to check the plugin version."
            );
            return;
        }

        switch (args.Parameters[0].ToLowerInvariant())
        {
            case "version":
                args.Player.SendInfoMessage(
                    "[RPGClasses] Version 0.1.0 | Base system loaded."
                );
                break;

            default:
                args.Player.SendErrorMessage(
                    "Unknown subcommand. Use /rpg or /rpg version."
                );
                break;
        }
    }
}
